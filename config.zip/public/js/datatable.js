//new DataTable('#example');

// //new DataTable('.data-table');
new DataTable('#exampl',{
    language: {
        info: 'Mostrando la pagina _PAGE_ de _PAGES_',
        infoEmpty: 'No hay registros disponibles',
        infoFiltered: '(filtrado de _MAX_ registros totales)',
        lengthMenu: 'Mostrar  _MENU_ registros',
        zeroRecords: 'nada encontrado, disculpa',
        search: 'Buscar',
        paginate:{
            next: 'Siguiente',
            previous:'Anterior'
    }}
});