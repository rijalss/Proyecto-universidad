<head>
   <!-- ... -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
   <!-- ... -->
</head>
<div class="container text-center">
   <div class="modal fade" id="mostrarmodal" tabindex="-1" aria-labelledby="mostrarmodal" aria-hidden="true">
      <div class="modal-dialog">
         <div class="modal-content">
            <div class="modal-header">
               <h5 class="modal-title" id="mostrarmodal">Resultado <i class="fas fa-lightbulb"></i>
               </h5>
               <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">

               <div id="contenidodemodal"></div>
               <i class="fas fa-exclamation-triangle"></i>
            </div>
         </div>
      </div>
   </div>
</div>