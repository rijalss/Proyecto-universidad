<!-- TODO conectar a la principal -->
<link rel="stylesheet" href="style.css">

<body>
    <footer id="footer" class="bg-dark text-white py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <div class="row mt-1 text-center">

                        <p>&copy; 2024 Todos los derechos reservados.</p>
                    </div>
                </div>
    </footer>
</body>

</html>