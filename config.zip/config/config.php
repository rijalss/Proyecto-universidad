<?php

//--------------------Base de Datos---------------------------
define('_DB_NAME_', 'inventario'); // nombre de la BD a conectar
define('_DB_HOST_', 'localhost'); //  servidor local
define('_DB_USER_', 'root'); // usuario por defecto de MYSQL
define('_DB_PASS_', ''); // password creada a la hora de instalar MYSQL  en mi compu la instale sin clase por esa razón esta vacia 
//----------------------Zona Horario---------------------------
date_default_timezone_set('America/Caracas');
