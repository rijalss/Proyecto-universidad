# Sistema de Inventario

Este proyecto implementa un sistema de inventario para gestionar la entrada y salida de productos en la comunidad
